#!/usr/bin/env bash

vim \
   ../../Utils.pm \
   *.t \
   *.pl \
   *.sh \
   ;

exit 0;

